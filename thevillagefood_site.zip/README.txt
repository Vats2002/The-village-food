The Village Food — simple coming-soon site
Files included:
- index.html         (main page)
- logo.svg           (placeholder logo; replace with your real logo image)
- favicon.png        (simple placeholder favicon)
- README.txt         (this file)

How to use:
1. Replace logo.svg with your logo file (same name), and update phone/social links in index.html.
2. (Optional) Sign up at Formspree.io and replace the form action URL in index.html.
3. Upload files to your hosting provider (GoDaddy public_html), or deploy with GitHub Pages / Netlify.
